# Importamos librerias
from tkinter import *
from PIL import Image, ImageTk
import cv2
import imutils
import numpy as np
import os


# Colores
def movimiento():
    Video=cv2.VideoCapture(0, cv2.CAP_DSHOW)
    First_Frame=None
    while True:
        Check,frame=Video.read()
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        gray=cv2.GaussianBlur(gray,(21,21),0)
        if First_Frame is None:
            First_Frame=gray
            continue
        delta_frame=cv2.absdiff(First_Frame,gray)
        Threshold_frame=cv2.threshold(delta_frame,50,255,cv2.THRESH_BINARY)[1]
        Threshold_frame=cv2.dilate(Threshold_frame,None,iterations=2)
        (cntr,_)=cv2.findContours(Threshold_frame.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        for contour in cntr:
            if cv2.contourArea(contour)<1000:
                continue
            (x,y,w,h)=cv2.boundingRect(contour)
            cv2.rectangle(frame,(x,y),(x+w,y+h),(0,255,0),3)
        cv2.imshow('Frame',frame)
        Key=cv2.waitKey(1)
        if Key == ord('q'):
            break
    Video.release()
            

def reconocimiento():
    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    faceClassif = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    while True:
        ret,frame = cap.read()
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        faces = faceClassif.detectMultiScale(gray, 1.3, 5)
        for (x,y,w,h) in faces:
            cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
        cv2.imshow('frame',frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()

def almacenamiento():
    personName = "Personas"
    dataPath =("C:/Users/59175/Desktop/proyecto/recop")
    personPath = dataPath + '/' + personName
    if not os.path.exists(personPath):
        print('Carpeta creada: ',personPath)
        os.makedirs(personPath)
    cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    #cap = cv2.VideoCapture('Video.mp4')
    faceClassif = cv2.CascadeClassifier(cv2.data.haarcascades+'haarcascade_frontalface_default.xml')
    count = 0
    while True:
        ret, frame = cap.read()
        if ret == False: break
        frame =  imutils.resize(frame, width=640)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        auxFrame = frame.copy()
        faces = faceClassif.detectMultiScale(gray,1.3,5)
        for (x,y,w,h) in faces:
            cv2.rectangle(frame, (x,y),(x+w,y+h),(0,255,0),2)
            rostro = auxFrame[y:y+h,x:x+w]
            rostro = cv2.resize(rostro,(150,150),interpolation=cv2.INTER_CUBIC)
            cv2.imwrite(personPath + '/rotro_{}.jpg'.format(count),rostro)
            count = count + 1
        cv2.imshow('frame',frame)
        k =  cv2.waitKey(1)
        if k == 27 or count >= 300:
            break
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()

pantalla = Tk()
pantalla.title("GUI | TKINTER | VISION ARTIFICIAL | PEPITO PEREZ")
pantalla.geometry("1280x720")  # Asignamos la dimension de la ventana

imagenF = PhotoImage(file="logo (1).png")
background = Label(image = imagenF, text = "Fondo")
background.place(x = 0, y = 0, relwidth = 1, relheight = 1)

imagenMV = PhotoImage(file="Det.de Movimiento.png")
movimiento = Button(pantalla, text="movimiento", image= imagenMV, height="50", width="300", command=movimiento)
movimiento.place(x = 800, y = 300)

imagenBI = PhotoImage(file="Det.Rostros.png")
reconocimiento = Button(pantalla, text="reconocimiento", image=imagenBI, height="50", width="300", command=reconocimiento)
reconocimiento.place(x = 800, y = 400)

imagenBC = PhotoImage(file="Det.de Movimiento.png")
almacenamiento = Button(pantalla, text="almacenamiento", image= imagenBC, height="50", width="300", command=almacenamiento)
almacenamiento.place(x = 800, y = 500)

texto3 = Label(pantalla, text="DETECCION DE MOVIMIENTO")
texto3.place(x = 800, y = 300)
texto3 = Label(pantalla, text="DETECCION DE ROSTROS")
texto3.place(x = 800, y = 400)
texto3 = Label(pantalla, text="ALMACENAMIENTO DE ROSTROS")
texto3.place(x = 800, y = 500)


lblVideo = Label(pantalla)
lblVideo.place(x = 320, y = 50)

lblVideo2 = Label(pantalla)
lblVideo2.place(x = 470, y = 500)

pantalla.mainloop()



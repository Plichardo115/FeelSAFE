
import cv2

#oad the cascade
face_cascade = cv2.CascadeClassifier('haarcascade_frontalcatface_extended.xml')

# To capture video from webcam. 
cap = cv2.VideoCapture(0)
# To use a video file as input 
# cap = cv2.VideoCapture('filename.mp4')

while True:
    # Read the frame
    _, img = cap.read()
    # Convert to grayscale
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # Detect the faces
    faces = face_cascade.detectMultiScale(gray, 1.1, 4)
    # Draw the rectangle around each face
    for (x, y, w, h) in faces:
            cv2.rectangle(img, (x, y), (x+w, y+h), (255, 0, 0), 2)
            if (centX <= middle_width and centY <= middle_height):
                    print("SUJETO ESTA EN LA IZQUIERDA")
                    valueSend = (str(1)+"\n")
                    data = ser.write(valueSend.encode())
            elif (centX >= middle_width and centY <= middle_height):
                    print("SUJETO ESTA EN LA DERECHA")
                    valueSend = (str(2)+"\n")
                    data = ser.write(valueSend.encode())
            elif (centX <= middle_width and centY >= middle_height):
                    print("SUJETO TOMO UN CAMINO EN LA IZQUIERDA")
                    valueSend = (str(3)+"\n")
                    data = ser.write(valueSend.encode())
            elif (centX >= middle_width and centY >= middle_height):
                    print("SUJETO TOMO UN COMINO POR LA DERECHA")
                    valueSend = (str(4)+"\n")
                    data = ser.write(valueSend.encode())
    # Display
    cv2.imshow('img', img)
    # Stop if escape key is pressed
    k = cv2.waitKey(30) & 0xff
    if k==27:
        break
# Release the VideoCapture object
cap.release() 
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyCNcUOlYweGjKWSVZ9umcwi1oq_llOwSwY",
            authDomain: "localizar3-8ec12.firebaseapp.com",
            projectId: "localizar3-8ec12",
            storageBucket: "localizar3-8ec12.appspot.com",
            messagingSenderId: "943405745515",
            appId: "1:943405745515:web:cb7415ea4256399636782e"));
  } else {
    await Firebase.initializeApp();
  }
}

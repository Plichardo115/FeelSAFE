import 'package:flutter/material.dart';
import '/backend/backend.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static final FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  Future initializePersistedState() async {}

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  List<LatLng> _modulos = [
    LatLng(25.7250289, -100.3135084),
    LatLng(25.7272621, -100.309096),
    LatLng(25.7264421, -100.3105961),
    LatLng(25.776332, -100.1858101),
    LatLng(25.7201855, -100.2190114),
    LatLng(25.6861141, -100.3168909),
    LatLng(25.7945375, -100.0579835),
    LatLng(25.7856799, -100.0513511),
    LatLng(25.7931017, -100.0791264),
    LatLng(25.7465111, -100.2912008),
    LatLng(25.6680642, -100.2579094),
    LatLng(25.6786078, -100.2842013),
    LatLng(25.6745177, -100.3473334),
    LatLng(25.7849809, -100.1915362),
    LatLng(25.7634228, -100.4178833),
    LatLng(25.7853567, -100.244345),
    LatLng(25.3849784, -100.161222),
    LatLng(25.7639265, -100.370142),
    LatLng(25.798097, -100.055717),
    LatLng(25.79322, -100.057653),
    LatLng(25.794465, -100.051597),
    LatLng(25.80245, -100.051616),
    LatLng(25.807684, -100.056004),
    LatLng(25.788397, -100.052258),
    LatLng(25.78264, -100.044237),
    LatLng(25.77908, -100.025252)
  ];
  List<LatLng> get modulos => _modulos;
  set modulos(List<LatLng> _value) {
    _modulos = _value;
  }

  void addToModulos(LatLng _value) {
    _modulos.add(_value);
  }

  void removeFromModulos(LatLng _value) {
    _modulos.remove(_value);
  }

  void removeAtIndexFromModulos(int _index) {
    _modulos.removeAt(_index);
  }

  void updateModulosAtIndex(
    int _index,
    Function(LatLng) updateFn,
  ) {
    updateFn(_modulos[_index]);
  }

  String _localidad = '';
  String get localidad => _localidad;
  set localidad(String _value) {
    _localidad = _value;
  }

  String _calle = '';
  String get calle => _calle;
  set calle(String _value) {
    _calle = _value;
  }

  String _numero = '';
  String get numero => _numero;
  set numero(String _value) {
    _numero = _value;
  }

  String _codigopostal = '';
  String get codigopostal => _codigopostal;
  set codigopostal(String _value) {
    _codigopostal = _value;
  }

  List<LatLng> _metropolitanzone = [
    LatLng(25.6866142, -100.3161126),
    LatLng(25.776468, -100.1858743),
    LatLng(25.8002233, -100.3122083),
    LatLng(25.7493469, -100.2868973),
    LatLng(25.6573447, -100.4017501),
    LatLng(25.801032, -100.5861995),
    LatLng(25.5859879, -99.99681670000001),
    LatLng(25.6746058, -100.4423188),
    LatLng(25.7917265, -100.0485536),
    LatLng(25.6516471, -100.1059194)
  ];
  List<LatLng> get metropolitanzone => _metropolitanzone;
  set metropolitanzone(List<LatLng> _value) {
    _metropolitanzone = _value;
  }

  void addToMetropolitanzone(LatLng _value) {
    _metropolitanzone.add(_value);
  }

  void removeFromMetropolitanzone(LatLng _value) {
    _metropolitanzone.remove(_value);
  }

  void removeAtIndexFromMetropolitanzone(int _index) {
    _metropolitanzone.removeAt(_index);
  }

  void updateMetropolitanzoneAtIndex(
    int _index,
    Function(LatLng) updateFn,
  ) {
    updateFn(_metropolitanzone[_index]);
  }

  String _nombreP1 = '';
  String get nombreP1 => _nombreP1;
  set nombreP1(String _value) {
    _nombreP1 = _value;
  }

  String _nombreP2 = '';
  String get nombreP2 => _nombreP2;
  set nombreP2(String _value) {
    _nombreP2 = _value;
  }

  String _Numero1P1 = '';
  String get Numero1P1 => _Numero1P1;
  set Numero1P1(String _value) {
    _Numero1P1 = _value;
  }

  String _numero2P1 = '';
  String get numero2P1 => _numero2P1;
  set numero2P1(String _value) {
    _numero2P1 = _value;
  }

  String _numero2P2 = '';
  String get numero2P2 => _numero2P2;
  set numero2P2(String _value) {
    _numero2P2 = _value;
  }

  String _numero1P2 = '';
  String get numero1P2 => _numero1P2;
  set numero1P2(String _value) {
    _numero1P2 = _value;
  }
}

LatLng? _latLngFromString(String? val) {
  if (val == null) {
    return null;
  }
  final split = val.split(',');
  final lat = double.parse(split.first);
  final lng = double.parse(split.last);
  return LatLng(lat, lng);
}
